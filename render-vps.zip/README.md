# render.vps

Proyek Node.js sederhana untuk dijalankan di Render.

## Cara Deploy
1. Upload repo ini ke GitHub
2. Buka https://render.com
3. Klik "New > Web Service"
4. Hubungkan akun GitHub dan pilih repo ini
5. Build command: `npm install`
6. Start command: `npm start`
